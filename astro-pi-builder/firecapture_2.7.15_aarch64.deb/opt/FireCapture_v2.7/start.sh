#!/bin/bash
#
# FireCapture Startup script 

heap=1024
useUserHome="$(cat FireCapture.ini | grep useUserHome | cut -d'=' -f2)"

if [ "$useUserHome" == "true" ]
then
   heap="$(cat $HOME/FireCapture/FireCapture.ini | grep heapsize | cut -d'=' -f2)"
else
   heap="$(cat FireCapture.ini | grep heapsize | cut -d'=' -f2)"
fi

cp=$(find lib -name "*.jar" -exec printf {}: ';')
if [[ -n "$CLASSPATH" ]] 
then
    cp="${cp}${CLASSPATH}"
fi

./jre/bin/java -Xms${heap}m -Xmx${heap}m -classpath "$cp" de.wonderplanets.firecapture.gui.FireCapture

read -r -p "Press any key to continue"

